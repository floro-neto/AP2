#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(){
    setlocale(LC_ALL,"Portuguese");

    int n;
    printf("Digite um n�mero:\n");
    scanf("%d", &n);
    n = (n % 2 == 0) ? printf("PAR") : printf("IMPAR");
    return 0;
}
