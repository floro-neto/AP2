#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main()
{
    setlocale(LC_ALL,"Portuguese");
    int n,d,f;

    printf("Digite dois n�meros:\n");
    scanf("%d %d", &n, &d);
    if (n < d)
    {
        printf("ordem crescente:\n");
        for (f = n; f <= d; f++)
        {
            printf("%d ", f);
        }
        printf("\n");
    }
    else if (n > d)
    {
        printf("ordem decrescente:\n");
        for (f = n; f >= d; f--)
        {
            printf("%d ", f);
        }
        printf("\n");
    }
    else
    {
        printf("valores iguais\n");
    }

}
