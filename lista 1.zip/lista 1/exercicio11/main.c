#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{ setlocale(LC_ALL,"Portuguese");
float nota[6] = {0};
float media = 0;
int menor = 0;
for (int i = 0; i < 6; i++) {
        printf("Digite a nota do aluno %d (entre 0 e 10): ", i + 1);
        scanf("%f", &nota[i]);
        if (nota[i] < 6){
            menor++;
        }
}
printf("Notas:\n");
for (int i = 0; i < 6; i++) {
        printf("Aluno %d: %.2f\n", i + 1, nota[i]);
    }
    float total = 0;
    int n1 = 0;
    for (int i = 0; i < 6; i++) {
        if (nota[i] >= 6) {
            total += nota[i];
            n1++;
        }

}
if (n1 > 0) {
        media = total / n1;
        printf("M�dia das notas acima de 6: %.2f\n", media);
    }
     printf("Quantidade de notas abaixo de 6: %d\n", menor);
}
