#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
    setlocale(LC_ALL,"Portuguese");
    int d;

    printf("Escolha um exerc�cio:\n");
    scanf("%d",&d);

    switch(d)
    {
    case 1:
        printf("Exercicio 1");
        break;
    case 2:
        printf("Exercicio 2");
        break;
    case 3:
        printf("Exercicio 3");
        break;
    case 4:
        printf("Exercicio 4");
        break;
    case 5:
        printf("Exercicio 5");
        break;
    case 6:
        printf("Exercicio 6");
        break;
    case 7:
        printf("Exercicio 7");
        break;
    case 8:
        printf("Exercicio 8");
        break;
    case 9:
        printf("Exercicio 9");
        break;
    case 10:
        printf("Exercicio 10");
        break;
    case 11:
        printf("Exercicio 11");
        break;
    case 12:
        printf("Exercicio 12");
        break;
    }

}
