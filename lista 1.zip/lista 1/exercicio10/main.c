#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main()
{ setlocale(LC_ALL,"Portuguese");
    int n;
    printf("Digite um n�mero: ");
    scanf("%d", &n);

    if (n < 0) {
        printf("digite n�meros positivos.\n");
    } else {
        int a = 0, b = 1, i, f;

        printf("Sequ�ncia de Fibonacci dos primeiros %d n�meros:\n", n);
        printf("%d, %d, ", a, b);

        for (int i = 2; i < n; i++) {
            f = a + b;
            printf("%d, ", f);
            a = b;
            b = f;
        }

        printf("\n");
    }

    return 0;
}

