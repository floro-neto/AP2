#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
    setlocale(LC_ALL,"Portuguese");
    int  n, a;
    printf("Digite um n�mero:\n");
    scanf("%d", &n);

    a = 1;
    if (n < 0){
        printf("digite valores inteiros e positivos\n");
    }else{

    do
    {

        if (a % 2 == 1){
                printf("%d", a);

           }else {
               printf("%d", -a);
           }
            a++;
        }while (a <= n);
    printf("\n");
    return 0;
    }
}
