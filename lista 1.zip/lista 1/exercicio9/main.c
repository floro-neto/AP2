#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
int main()
{
    setlocale(LC_ALL,"Portuguese");
    int a,b,c;
    printf("Digite um n�mero:\n");
    a = 1;
    b = 1;
    scanf("%d", &c);
    if (c < 0){
        printf("digite valores positivos");
    }else{
    while(b <= c){
        a *= b;
        b++;
    }
    printf("O fatorial de %d � %d",c,a);
}
}
