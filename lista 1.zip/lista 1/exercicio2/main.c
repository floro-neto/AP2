#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
    setlocale(LC_ALL,"Portuguese");

   int idade = 0;
   printf("Digite sua idade:\n");
   scanf("%d", &idade);

   	printf("Voc� tem %d anos.\n", idade);
}
