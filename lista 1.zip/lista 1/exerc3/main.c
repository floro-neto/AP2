#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
    setlocale(LC_ALL,"Portuguese");
    int n = 0;
    printf("Digite um n�mero:\n");
    scanf("%d", &n);

    printf("O n�mero em octal � %o\n", n);
    printf("O n�mero em hexa � %x", n);

}
