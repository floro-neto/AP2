#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 1;
    int b = 2;
    int c = ++a + b++;

    printf("a = %d, b = %d, c = %d\n", a, b, c);
}
